$('.your-class').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    // autoplay: true,
    infinite: true,
    dots:true,
    // autoplaySpeed: 2000,
    // navs:true, 
    // prevArrow: '<button class="navs next"><i class="bi bi-arrow-left"></i></button>',
    // nextArrow: '<button class="navs previous"><i class="bi bi-arrow-right"></i></button>',
  });